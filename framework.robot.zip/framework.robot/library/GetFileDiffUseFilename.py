import difflib
import sys
import urlparse
import os
import time

#testFile = "C:\\Python27\\framework.robot\\library\\Output.txt"
#comparisonFile = "C:\\Python27\\framework.robot\\library\\Output2.txt"

#expectFile = "C:\\Python27\\framework.robot\\testsuites\\acura_com\\acura_homepage\\data\\ACTUAL_www.acura.com_ilx_features.txt"
#actualFile = "C:\\Python27\\framework.robot\\testsuites\\acura_com\\acura_homepage\\data\\BASELINE_www.acura.com_ilx_features.txt"

def get_file_diff_use_filename(base_file_name, file_location):

    #--------------------------------------------
    #FILE
    #--------------------------------------------
    #split_url = urlparse.urlsplit(this_url)
    # You now have:
    # split_url.scheme   "http"
    # split_url.netloc   "127.0.0.1" 
    # split_url.path     "/asdf/login.php"
    # split_url.query    ""
    # split_url.fragment ""

    print "suffix"
    print "---------------------------------"
    suffix_baseline = "_baseline"
    suffix_actual = "_actual"
    suffix_diff = "_diff"

    ext = ".txt"
    #print "-- --" + split_url 
    
    #file format
    #file_parent_dir = os.path.dirname(os.path.dirname('_file_'))
    #cwd = os.getcwd()
    #file_parent_dir = cwd     #os.path.dirname(os.path.abspath('_file_'))
    #print file_parent_dir
    
    #file_absolute_location = os.path.join(file_parent_dir, file_parent_dir + '\\' + file_location)

    file_location =   file_location.replace("//", "\\")
    print file_location
    this_baseline_file = file_location + base_file_name + suffix_baseline + ext
    this_actual_file = file_location + base_file_name + suffix_actual + ext
    this_diff_file =  file_location + base_file_name + suffix_diff + ext
    text_file = open(this_diff_file , "wb")    #wb = write


    now = time.strftime("%c")

    with open(this_baseline_file, 'r') as baseline:
        with open(this_actual_file, 'r') as actual:
            diff = difflib.unified_diff(
                baseline.readlines(),
                actual.readlines(),
                fromfile='baseline',
                tofile='actual',
                n=0,
            )
        print "count"
        count = 0
        print "count1"
        for line in diff:
            text_file.write(line)   
            print line
            count=count + 1
       
        #if count ==0: 
        #    text_file.write(now + "  NO CHANGES FOUND" )
        
        #print "COUNT LINE DIFF " + count
        #if diff.count > 0: 
        text_file.close()

        print "count2"
 
    #Raise error if changes are found 
    if count >0:
        raise ValueError("Difference found between Baseline and Actual.  See file " + this_diff_file )

    print "--- DIFF FOUND ---", this_diff_file
    return  this_diff_file
