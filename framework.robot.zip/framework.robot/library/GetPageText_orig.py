import urllib
from bs4 import BeautifulSoup
import urlparse
#--------------------------------------------------------------------------
#REQUIREMENTS: 
#INSTALLATION OF LIBRARY: 
#1. urllib 
#   open command prompt > go to c:\python27\scripts > enter: pip install urllib
#	if error exist, please confirm lib 'urllib.py' exit on c:\python27\Lib 
#2. bs4
#   open command prompt > go to c:\python27\scripts > enter: pip install bs4
#3. BeautifulSoup
#   open command prompt > go to c:\python27\scripts > enter: pip install BeautifulSoup
#4. Check version 
#   open command prompt > go to c:\python27\scripts > enter: pip freeze
#   you should see installed libraries and version
#5. To run the script
#   change url on line 22
#	open command prompt > go to c:\python27\scripts > enter: python GetPageText.py
#6. Output file
#   Output file is saved to \library\Output.txt
#7. Filename = url + .txt
#--------------------------------------------------------------------------

def get_page_text(this_url, save_to, is_baseline):
	#arguments:
	#this_url == website, files generated is based on url
	#save_to  == location of file ex ..\\..\\..\\library\\
	#is_baseline == 0 = false, 1 = true

	url = this_url     #"http://www.acura.com/ilx/specs"   #update here
	html = urllib.urlopen(url).read()
	soup = BeautifulSoup(html, 'html.parser')
	

	# kill all script and style elements
	for script in soup(["script", "style"]):
	    script.extract()    # rip it out

	# get text
	text = soup.get_text()

	print "-- --" + text 

	# break into lines and remove leading and trailing space on each
	lines = (line.strip() for line in text.splitlines())
	# break multi-headlines into a line each
	chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
	# drop blank lines
	text = '\n'.join(chunk for chunk in chunks if chunk)

	#--------------------------------------------
	#FILE
	#--------------------------------------------
	split_url = urlparse.urlsplit(this_url)
	# You now have:
	# split_url.scheme   "http"
	# split_url.netloc   "127.0.0.1" 
	# split_url.path     "/asdf/login.php"
	# split_url.query    ""
	# split_url.fragment ""

	print "---------------------------------"
	#print "-- --" + split_url 
	this_file =   split_url.netloc + split_url.path      
	this_file =   this_file.replace("/", "_")
	#this_file =   this_file.replace(".", "_")
	#text_file = open("..\\..\\..\\library\\" + this_file + ".txt", "wb") 
	if is_baseline == "1": 
		#print "--- is baseline ----"
		#print "--- " + this_file + "---" 
		this_file = "baseline_" + this_file 
		#print "--- " + this_file + "---" 
	else:
		this_file = "actual_" + this_file 
		#print "--- " + this_file + "---" 


	this_file = save_to + this_file + ".txt"  
	text_file = open(this_file, "wb")     
	#text_file = open("..\\framework.robot\\library\\Output.txt", "wb")
	text_file.write(text.encode('utf-8'))
	text_file.close()


	print(text.encode('utf-8'))
	print '---- FILE CREATED ---  ' + save_to + this_file + ' ---' 
	return  save_to + this_file 