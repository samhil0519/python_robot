import difflib
import sys
import urlparse
import os
import time

#testFile = "C:\\Python27\\framework.robot\\library\\Output.txt"
#comparisonFile = "C:\\Python27\\framework.robot\\library\\Output2.txt"

#expectFile = "C:\\Python27\\framework.robot\\testsuites\\acura_com\\acura_homepage\\data\\ACTUAL_www.acura.com_ilx_features.txt"
#actualFile = "C:\\Python27\\framework.robot\\testsuites\\acura_com\\acura_homepage\\data\\BASELINE_www.acura.com_ilx_features.txt"

def get_file_diff(this_url, file_location):

    #--------------------------------------------
    #FILE
    #--------------------------------------------
    split_url = urlparse.urlsplit(this_url)
    # You now have:
    # split_url.scheme   "http"
    # split_url.netloc   "127.0.0.1" 
    # split_url.path     "/asdf/login.php"
    # split_url.query    ""
    # split_url.fragment ""

    print "---------------------------------"
    #print "-- --" + split_url 
    this_file =   split_url.netloc + split_url.path      
    this_file =   this_file.replace("/", "_")
    #this_file =   this_file.replace(".", "_")
    #text_file = open("..\\..\\..\\library\\" + this_file + ".txt", "wb") 

    #file format
    this_baseline_file = file_location + "baseline_" + this_file + ".txt"
    this_actual_file = file_location + "actual_" + this_file + ".txt"
    this_diff_file =  file_location + "diff_" + this_file + ".txt"
    text_file = open(this_diff_file , "wb") 

    now = time.strftime("%c")

    with open(this_baseline_file, 'r') as baseline:
        with open(this_actual_file, 'r') as actual:
            diff = difflib.unified_diff(
                baseline.readlines(),
                actual.readlines(),
                fromfile='baseline',
                tofile='actual',
                n=0,
            )
       
        
        count = 0
        for line in diff:
            text_file.write(line)   
            print line
            count=count + 1
    
    if count ==0: 
        text_file.write(now + "  NO CHANGES FOUND" )

    text_file.close()
 
    #Raise error if changes are found 
    if count >0:
        raise ValueError("Difference found between Baseline and Actual.  See file " + this_diff_file )

    print "--- DIFF FOUND ---" + this_diff_file
    return  this_diff_file
