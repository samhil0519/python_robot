from PIL import Image
from PIL import ImageChops


def diff_image(file_location, img1, img2):

        diffcount = 0.0
        im1 = Image.open("C://Hawk_Automation//framework.robot//testsuites//automobiles_honda_com//accord//im._baseline.png")
        im2 = Image.open("C://Hawk_Automation//framework.robot//testsuites//automobiles_honda_com//accord//im.png")
 
        imgcompdiff = ImageChops.difference(im1, im2)
        diffboundrect = imgcompdiff.getbbox()
        imgdiffcrop = imgcompdiff.crop(diffboundrect)
 
        data = imgdiffcrop.getdata()
        #print "---seq---"
        seq = []
        for row in data:
            seq += list(row)
        
        #print "---xrange---"
        for i in xrange(0, imgdiffcrop.size[0] * imgdiffcrop.size[1] * 3, 3):
            if seq[i] != 0 or seq[i+1] != 0 or seq[i+2] != 0:
                diffcount = diffcount + 1.0
         
        diffImgLen = imgcompdiff.size[0] * imgcompdiff.size[1] * 1.0
        diffpercent = (diffcount * 100) / diffImgLen
        print   diffpercent
        print str(int(float(diffpercent)))   + "%" +" difference found between baseline and actual image"

        #return diffpercent
        if int(float(diffpercent)) > 10:
            raise ValueError(str(int(float(diffpercent)))   + " Difference found between Baseline and Actual.  See file " + this_diff_file )
