import pyscreenshot as ImageGrab

#

def get_screenshot_window():
	# fullscreen
	#im=ImageGrab.grab()
	#im.show()

	# part of the screen
	# this will grab a 400 pixel wide and 300 pixel heigh partion
    # upper left corner screen coordinates x=0, y=0
	im=ImageGrab.grab(bbox=(10,10,550,767))
	#im.show()
	im.save('im.png')

	# to file
	#ImageGrab.grab_to_file('im.png')