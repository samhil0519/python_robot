from selenium import webdriver
import time
import win32com.client



def authentication(this_user, this_password):

#	Taken from https://codedump.io/share/kZkKII74OcOQ/1/how-to-handle-windows-authentication-popup-in-robot-framework-ride 
#	This function authenticate with User and Passord on the site. Must be used when Site require authentication
#   Require install pywin32-220.win32-py2.7.exe And AutoItLibrary-1.1

	print " Authentication Initiated"
	
	shell = win32com.client.Dispatch("WScript.Shell")   

	shell.Sendkeys(this_user)  

	shell.Sendkeys("{TAB}")

	shell.Sendkeys(this_password) 

	time.sleep(2)

	shell.Sendkeys("{ENTER}")
